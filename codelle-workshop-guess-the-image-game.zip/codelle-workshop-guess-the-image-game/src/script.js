var numLife = 3;

var images = ["https://i.ytimg.com/vi/1Ne1hqOXKKI/maxresdefault.jpg",
"https://d1uep5tseb3xou.cloudfront.net/content/images/thumbs/0013662_memorial-tree_540.png","https://assets.bonappetit.com/photos/5f84743360f032defe1f5376/4:3/w_1648,h_1236,c_limit/Pullman-Loaf-Lede-new.jpg","https://storcpdkenticomedia.blob.core.windows.net/media/recipemanagementsystem/media/recipe-media-files/recipes/retail/desktopimages/rainbow-cake600x600_2.jpg?ext=.jpg", "https://cdn11.bigcommerce.com/s-q83qdckkjh/images/stencil/1280x1280/products/120/2562/Monarch-Butterfly-Flower-MixBC__93612.1620252784.jpg?c=2?imbypass=on","https://c.s-microsoft.com/en-us/CMSImages/1920_Panel01_FullWidthHero_Desktops.jpg?version=b34847cc-341d-a8c4-d3ce-3453f3e32e18","https://t3.ftcdn.net/jpg/03/13/56/02/360_F_313560286_LpqFHYW7LZ7UcN7VV29dMivjVFVNvju7.jpg","https://cdn.pixabay.com/photo/2017/01/08/13/58/cube-1963036__340.jpg","https://mk0culverduckguu41sc.kinstacdn.com/wp-content/uploads/2020/11/duck-animate-1-500x500.png","https://image.shutterstock.com/image-photo/ripe-red-apple-fruit-half-260nw-699645961.jpg","https://media.istockphoto.com/photos/pen-picture-id1059543698?k=20&m=1059543698&s=612x612&w=0&h=7WqjxvoS-VOR6-zyg_8zXP3TofY0AH-Ga4Sj5VudsB4=","https://www.jessicagavin.com/wp-content/uploads/2020/07/how-to-cook-pasta-3-1200.jpg","https://www.twosisterscrafting.com/wp-content/uploads/2016/01/perfect-stovetop-popcorn-1200-featured-720x540.jpg","https://upload.wikimedia.org/wikipedia/commons/thumb/4/45/A_small_cup_of_coffee.JPG/1200px-A_small_cup_of_coffee.JPG","https://www.sephora.com/productimages/sku/s2245751-main-zoom.jpg?imwidth=315","https://homedepot.scene7.com/is/image/homedepotcanada/p_1000724889.jpg?wid=1000&hei=1000&op_sharpen=1","https://www.seriouseats.com/thmb/AUw679s1qSus3eIxZ7Xis8CHu-o=/610x343/smart/filters:no_upscale()/__opt__aboutcom__coeus__resources__content_migration__serious_eats__seriouseats.com__recipes__images__2011__08__20110817-166611-flour-croissants-fb708f60c6b943588a4407033182d8a0.jpg","https://www.zdnet.com/a/hub/i/r/2020/06/09/2eacd230-d144-4224-9e64-aa012e900877/thumbnail/770x578/1ebfd4a1739a495a71f5a946a701c186/coca-cola-coke-coca-cola.jpg","https://www.theschooloflife.com/shop/eu/pub/media/catalog/product/cache/6c2a5caf01241b5c5f2ab13f583665eb/u/t/utopia_candle_-_the_republic_-_resized_2__1.jpg"]

var imageAnswer = ["cat", "tree","bread","cake","butterfly","computer","sunset","dice","duck","apple","pen","pasta","popcorn","coffee","lipstick","fan","croissant","coke","candle"]
var randImgLink="";
var randImgAnswr = "";
var randomImgIndex = "";

document.getElementById("guess").style.display = 'none';
document.getElementById("submit").style.display = 'none';

function changePicture() {
  numLife= 3;
  message.innerHTML = ""
  document.getElementById("myLives").innerHTML = "You have " + numLife + " lives left."
  document.getElementById('guessImage').style.filter = 'blur(15px)';

  document.getElementById("submit").style.display = 'inline';
  document.getElementById("guess").style.display = 'inline';
  randomImgIndex = Math.floor(Math.random() * images.length);
  randImgLink = images[randomImgIndex];
  randImgAnswr = imageAnswer[randomImgIndex];
 
 document.getElementById("guessImage").src= randImgLink;  
}

function checkLives() {
  if(numLife > 0) {
    document.getElementById("myLives").innerHTML = "You have " + numLife + " lives left."
  }
  else{
    document.getElementById("myLives").innerHTML = "No more lives left.."
    document.getElementById("submit").style.display = 'none';
  }
}


function checkWord() {

  var wordGuessed = document.getElementById("guess").value;
  
  if (randImgAnswr.toLowerCase() == wordGuessed.toLowerCase()) {
     message.innerHTML = "Congratulations! The answer was " + randImgAnswr + "🎉" 
   
  document.getElementById('guessImage').style.filter = 'blur(0px)';
  document.getElementById("submit").style.display = 'none';
    
  }
  else
    {
      numLife = numLife - 1;
      checkLives()
    }
  
}